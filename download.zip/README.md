# Portfolio Site

A personal portfolio site for my friend Darko, build from scratch to fit his general idea.

# TODO

- Make the diagonal cuts show underlying images
- More content on index page
- Resume/about page
- Hover title effects
