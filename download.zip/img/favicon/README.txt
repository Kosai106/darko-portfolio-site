Drop in your favicons here.

The sizes supported currently are:
16x16
32x32
96x96
144x144

--

The favicons should be named after the sizes, and they have to be .PNG's.
Example: 32x32.png, 144x144.png